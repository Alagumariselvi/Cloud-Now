export default function Banner(){
    return(
        <div className="banner">
            <div className="bannerText">
                <p className="bannerHead">A Digital Product Agency</p>
                <p className="bannerSub">Leading digital agency with solid design and development<br/>
                 expertise. We build readymade websites, mobile<br/>
                  applications, and elaborate online business services.</p>
                <button className="bannerButton">
                    Contact Now
                </button>
            </div>
            <div className="bannerImg">
                <img src={require("../Images/banner.png")} className="bannerImage" alt="bannerImage"/>
            </div>
        </div>
    )
}