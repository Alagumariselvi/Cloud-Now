import icons from "../Icons/icons";
import { getIcon } from "../getIcons";
export default function Business(){
    return(
        <div className="banner business">
            <div className="businessText">                
                <p className="bannerHead businessHead">How can we help<br/> your Business ?</p>
                <img src={require("../Images/bg.png")} alt="businessBg" className="businessBg" />
                <p className="bannerSub businessSub">We build readymade websites, mobile<br/>
                 applications, and elaborate online business <br/>
                 services.</p>
            </div>
            <div className="businessImg">
                <div className="row">
                    <div className="column card1">
                        <div className="cardbg cardbg1">
                        <span className="icons">{getIcon({ iconList: icons, iconName: 'BusinessIcon'})}</span>                        
                        </div>
                        <p className="cardHeading">Business Idea <br/>Planning</p>
                        <p className="cardSub">We present you a proposal <br/>and discuss niffty-gritty like</p>
                    </div>
                    <div className="column card2">
                    <div className="cardbg cardbg2">
                    <span className="icons">{getIcon({ iconList: icons, iconName: 'FinancialIcon'})}</span>
                    </div>
                    <p className="cardHeading">Financial Planning System</p>
                        <p className="cardSub">Protocols apart from aengage models, pricing billing</p>
                  </div>
                </div>
                <div className="row">
                    <div className="column card3">
                    <div className="cardbg cardbg3">
                    <span className="icons">{getIcon({ iconList: icons, iconName: 'DevelopmentIcon'})}</span>
                   
                    </div>
                    <p className="cardHeading">Development<br/> Website and App</p>
                    <p className="cardSub">Communication protocols<br/> apart from engagement<br/>models</p>
                    </div>
                    <div className="column card4">
                    <div className="cardbg cardbg4">
                    <span className="icons">{getIcon({ iconList: icons, iconName: 'MarketIcon'})}</span>
                     </div>
                     <p className="cardHeading">Market Analysis<br/> Project</p>
                    <p className="cardSub">Protocols apart from aengage models, pricing billing</p>
                 
                    </div>
                </div>
          
            </div>
        </div>
    )
}