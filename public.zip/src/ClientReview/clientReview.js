import { getIcon } from "../getIcons";
import icons from "../Icons/icons";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
export default function ClientReview(){
    
const responsive = {
    superLargeDesktop: {
      // the naming can be any, depends on you.
      breakpoint: { max: 4000, min: 3000 },
      items: 1
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 1
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 1
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 1
    }
  };

const reviews=[{
    img:'customer.png',
    name:'Matthew Paul',
    review:'Perfect, very good job! Thank you for the amazing<br/> design and work. Really impressed with the high quality<br/> and quick turnaround time. Highly<br/> recommend.'
},
{
    img:'customer.png',
    name:'Mark',
    review:'Perfect, very good job! Thank you for the amazing<br/> design and work. Really impressed with the high quality<br/> and quick turnaround time. Highly<br/> recommend.'
},
{
    img:'customer.png',
    name:'John',
    review:'Perfect, very good job! Thank you for the amazing<br/> design and work. Really impressed with the high quality<br/> and quick turnaround time. Highly<br/> recommend.'
},{
    img:'customer.png',
    name:'Christi',
    review:'Perfect, very good job! Thank you for the amazing<br/> design and work. Really impressed with the high quality<br/> and quick turnaround time. Highly<br/> recommend.'
},{
    img:'customer.png',
    name:'Paul',
    review:'Perfect, very good job! Thank you for the amazing<br/> design and work. Really impressed with the high quality<br/> and quick turnaround time. Highly<br/> recommend.'
}
]
    return(
        <div>
            <p className="bannerHead" style={{textAlign:'center'}}>What our happy client say</p>
            <p className="bannerSub" style={{textAlign:'center',marginRight:'0px'}}>Several selected clients, who already believe in our service.</p>
            <div className="row">
                <div className="column1">
                    <Carousel responsive={responsive}    showDots={true}
                    slidesToSlide={1}
                    containerClass="container-with-dots"
                    deviceType={''}
                    arrows={false}
                    // centerMode={true}
                    >
                        {reviews.map((review)=>(
                            <div style={{justifyContent:'center'}} className="row">
                            <div>
                                <img src={require(`../Images/${review.img}`)} style={{width:'339px',height:'339px'}}/>
                            </div>
                            <div className="content">
                                <p className="customerName">{review.name}</p>
                                <p className="review" dangerouslySetInnerHTML={{__html: review?.review}}></p>
                            </div>
                            </div>
                        ))}                 

                    </Carousel>
                </div >
                <div className="column3">
                    <Carousel responsive={responsive}    showDots={true}
                    slidesToSlide={1}
                    containerClass="container-with-dots"
                    deviceType={''}
                    arrows={false}
                    // centerMode={true}
                    >
                        {reviews.map((review)=>(
                            <div style={{justifyContent:'center'}} className="row">
                            <div>
                                <img src={require(`../Images/${review.img}`)} style={{width:'439px',height:'239px'}}/>
                            </div>
                            <div className="content">
                                <p className="customerName">{review.name}</p>
                                <p className="review" dangerouslySetInnerHTML={{__html: review?.review}}></p>
                            </div>
                            </div>
                        ))}                 

                    </Carousel>
                </div >
                <div className="column2">{getIcon({ iconList: icons, iconName: 'RoundedIcon'})}</div>
            </div>
        </div>
    )
}