import { Link } from "react-router-dom"
import { useState } from "react"
export default function Header(){
    const menus=[{
        menu:"Home",
        link:"/"
    },{
        menu:"What We Do",
        link:'/about'
    },{
        menu:"Service",
        link:"/services"
    },{
        menu:"Project",
        link:"/projects"
    },{
        menu:"Blog",
        link:"/blog"
    },{
        menu:"Contact",
        link:"/contact"
    }]
    const [isNavExpanded, setIsNavExpanded] = useState(false)
    return(
      <nav className="navigation">
        <div className="logo">
         <p className="logoText">A+<span className="logoSub">Studio</span></p>
        </div>
        <button
          className="hamburger"
          onClick={() => {
            setIsNavExpanded(!isNavExpanded)
          }}
        >
         <svg viewBox="0 0 100 80" width="30" height="30">
            <rect width="80" height="10" fill="#FFFFFF"></rect>
            <rect y="30" width="60" height="10" fill="#FFFFFF"></rect>
            <rect y="60" width="80" height="10" fill="#FFFFFF"></rect>
        </svg>
        </button>
        <div
          className={
            isNavExpanded ? "navigation-menu expanded" : "navigation-menu"
          }
        >
           <ul className="menus">
            {menus?.map((menu)=>
                (
                    <Link to={menu.link} className="link">
                        <li>{menu.menu}</li>
                    </Link>
                ))}

            </ul>
        </div>
      </nav>
    )
}