export default function Footer(){
    return(
        <div className="footer">
            <p className="footerText">Copyright © 2023 Sample company</p>
        </div>
    )
}