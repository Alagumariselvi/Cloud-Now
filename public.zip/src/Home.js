import Banner from "./Banner/banner";
import Business from "./Business/business";
import ClientReview from "./ClientReview/clientReview";
import Footer from "./Footer/footer";
import Header from "./Header/header";

export default function Home(){
return(
    <>
    <Header/>
    <Banner/>
    <Business/>
    <ClientReview/>
    <Footer/>
    </>
)
}